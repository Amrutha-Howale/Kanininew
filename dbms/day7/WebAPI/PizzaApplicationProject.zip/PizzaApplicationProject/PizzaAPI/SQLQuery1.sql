select * from pizzas

Insert into pizzas 
values
('Pizza Pepperoni Blues', 21, 'Spicy', 'notVeg','img/a.jfif'),
('Pizza Margarita', 19, 'Cheesy', 'Veg','img/pizza4.jfif'),
('Pizza Manhattan', 20, 'Mashrooms', 'notVeg','img/c.jpg'),
('Pizza Toscana', 21, 'Cheesy', 'notVeg','img/pizzamain'),
('Pizza Five Cheeses', 22, 'Cheesy', 'Veg','img/pizzamain2'),
('VEG Loaded', 22, 'Veg', 'Veg','img/pizzamain3');

drop table pizzas

drop database DBPizzaAPI
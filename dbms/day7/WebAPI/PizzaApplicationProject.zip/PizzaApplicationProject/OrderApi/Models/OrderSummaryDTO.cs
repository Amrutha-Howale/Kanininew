﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderApi.Models
{
    public class OrderSummaryDTO
    {
        public int OrderId { get; set; }
        public string UserId { get; set; }
        public double? Total { get; set; }
        public double? DeliveryCharge { get; set; }
        public string Status { get; set; }
        public List<int> PizzaId { get; set; }
        public List<string> PizzaName { get; set; }
        public List<double> PizzaPrice { get; set; }
        public List<string> PizzaSpeciality { get; set; }
        public List<string> PizzaIsVeg { get; set; }
        public List<int> ToppingId { get; set; }
        public List<string> ToppingName { get; set; }
        public List<double> ToppingPrice { get; set; }
    }
}

﻿using OrderApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderApi.Services
{
    public class OrderSummaryService
    {
        private readonly OrderContext _context;
        private readonly OrderRepo _order;
        private readonly OrderDetailRepo _orderdetail;
        private readonly ToppingDetailRepo _toppingdetail;
        PizzaDTO pizzaDTO = new PizzaDTO();
        ToppingDTO toppingDTO = new ToppingDTO();
        
        public OrderSummaryService(OrderContext context, OrderRepo order, OrderDetailRepo orderDetail, ToppingDetailRepo toppingDetail)
        {
            _context = context;
            _order = order;
            _orderdetail = orderDetail;
            _toppingdetail = toppingDetail;
        }

        public OrderSummaryDTO summary()
        {
            OrderSummaryDTO summaryDTO = new OrderSummaryDTO();
            Order order = _context.Orders.OrderBy(o => o.OrderId).Last();
            if (order is null)
                return null;
            else
            {
                summaryDTO.UserId = order.UserId;
                summaryDTO.OrderId = order.OrderId;
                summaryDTO.Total = order.Total;
                summaryDTO.DeliveryCharge = order.DeliveryCharge;
                summaryDTO.Status = order.Status;
                summaryDTO.PizzaId = new List<int>();
                summaryDTO.ToppingId = new List<int>();

                List<OrderDetail> orderDetail = _context.OrderDetails.Where(od => od.OrderId==order.OrderId).ToList();
                foreach (var item in orderDetail)
                {
                    summaryDTO.PizzaId.Add(item.PizzaId);
                    if (item.PizzaId == pizzaDTO.PizzaId)
                    {
                        summaryDTO.PizzaName.Add(pizzaDTO.Name);
                        summaryDTO.PizzaPrice.Add(pizzaDTO.Price);
                        summaryDTO.PizzaSpeciality.Add(pizzaDTO.Speciality);
                        summaryDTO.PizzaIsVeg.Add(pizzaDTO.IsVeg);
                    }
                    List<ToppingDetail> topping = _context.ToppingDetails.Where(od => od.ItemId ==item.ItemId).ToList();
                        foreach (var ToppingItem in topping)
                        {
                        summaryDTO.ToppingId.Add(ToppingItem.ToppingId);
                        if (ToppingItem.ToppingId == toppingDTO.ToppingId)
                            {
                                summaryDTO.ToppingName.Add(toppingDTO.Name);
                                summaryDTO.ToppingPrice.Add(toppingDTO.Price);
                            }
                        }
                    }
                }
            return summaryDTO;
        }
    }
}

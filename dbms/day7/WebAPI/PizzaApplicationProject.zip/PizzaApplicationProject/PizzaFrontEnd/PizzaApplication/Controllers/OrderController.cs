﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PizzaApplication.Models;
using PizzaApplication.Models;
using PizzaApplication.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PizzaApplication.Controllers
{
    public class OrderController : Controller
    {
        private ILogger<OrderController> _logger;
        private readonly OrderService _ORepo;

        public OrderController(ILogger<OrderController> logger, OrderService ORepo)
        {
            _logger = logger;
            _ORepo = ORepo;
        }

        // POST api/<OrderController>
        [Route("AddOrder")]
        [HttpPost]
        public async Task<ActionResult<OrderDTO>> AddOrder([FromBody] UserDTO userDto)
        {
            Debug.WriteLine(" ===> Post Method : AddOrder ");
            if (userDto is null)
                return BadRequest();

            var newOrder = await _ORepo.AddOrder(userDto, TempData.Peek("Token").ToString());
            if (newOrder != null)
                return Ok(newOrder);
            return BadRequest("Not able to register");

        }

        /*[Route("GetOrder")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _ORepo.GetAll(TempData.Peek("Token").ToString()));
        }*/

        [Route("summary")]
        [HttpGet]
        public IActionResult summary()
        {
            OrderSummaryDTO summaryDTO =JsonConvert.DeserializeObject<OrderSummaryDTO> (_ORepo.summary());
            _logger.LogInformation(summaryDTO.Status);
            return View(summaryDTO);  

        }


    }
}
